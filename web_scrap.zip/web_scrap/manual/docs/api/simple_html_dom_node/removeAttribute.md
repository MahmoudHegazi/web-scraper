# removeAttribute

```php
removeAttribute ( string $name )
```

| Parameter | Description
| --------- | -----------
| `name`    | Name of the attribute to remove.

Removes the attribute with the speicified name from the current node.